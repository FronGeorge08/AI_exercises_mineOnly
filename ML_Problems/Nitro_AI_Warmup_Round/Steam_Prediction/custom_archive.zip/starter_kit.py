# Starter kit

import pandas as pd

df_train = pd.read_csv('train_data.csv')
df_test = pd.read_csv('test_data.csv')

subtask1 ='Avg Owners'
subtask2 = 'Price'

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

train, validation = train_test_split(df_train, test_size=0.2, random_state=0)

y_train = train[subtask2]
X_train = train.drop(columns=[subtask2])

y_validation = validation[subtask2]
X_validation = validation.drop(columns=[subtask2])

[INSERT CORECTARE / CURATARE DATE]
[INSERT ANTRENARE PE TRAIN SI VALIDATION]

model = model.fit(X_train, y_train)
y_pred = model.predict(X_validation)
print(accuracy_score(y_pred, y_validation))

df_test[subtask1] = [PREPROCESAREA CERUTA LA SUBTASK 1]
df_test[subtask2] = model.predict(df_test)
df_test[['AppID', subtask1, subtask2]].to_csv('prediction.csv', index=False)
